﻿internal class ReportDocument
{
}